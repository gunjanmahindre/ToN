#!/bin/bash
#normal_matrix_completion.py
#0 , 5, 10, 20, 40, 60, 80
#fraction = 0 #percentage of elements to be removed
#np.savetxt('nw_0.txt', dc, delimiter = '\t')
#run 7 times
#mean_error_ton.py
#Iteration_1
run=50
j=0
y=1
#rm -rf mean.txt
for x in $(eval echo "{1..$run}")
do
	for i in 0 5 10 20 40 60 80 90
	do
		echo "---------------------------------------------------------------------------------Iteration running is $x"
		echo "--------------------------------------------------------------------------------Percentage running is $i"
		sed -i "s|fraction = ${j}|fraction = ${i}|g" normal_matrix_completion_3D.py
		sed -i "s|nw_${j}.txt|nw_${i}.txt|g" normal_matrix_completion_3D.py
		#run script1
		~/anaconda3/bin/python3.6 normal_matrix_completion_3D.py
		j=$i
		if [ $i == 90 ]
		then
			sed -i "s|fraction = ${i}|fraction = 0|g" normal_matrix_completion_3D.py
			sed -i "s|nw_${i}.txt|nw_0.txt|g" normal_matrix_completion_3D.py
		fi
	done

	echo "---------------------------------------------------------------------------------------Iteration script running is $x" 
	sed -i "s|Iteration_${y}|Iteration_${x}|g" mean_error_ton.py
	#run script2
	~/anaconda3/bin/python3.6 mean_error_ton.py
	y=$x
	if [ $x == $run ]
	then
		sed -i "s|Iteration_${x}|Iteration_1|g" mean_error_ton.py
	fi
	echo "----------------------------------"
done

# Calculate average
FILE=mean_average.txt
for a in 0 5 10 20 40 60 80 90
do
	c=`cat mean.txt | grep "$a% " -c`
	total=0
	for b in $(eval echo "{1..$c}")
	do
		value=`cat mean.txt | grep "$a% " -m$b | tail -n1 | rev | cut -d' ' -f1 | rev`
		total=`echo $total + $value | bc`
	done
	total=`echo $total / $c | bc -l`
	echo "$a%     $total" >> $FILE
done

#FILE2=dev_average_hourglass.txt
#for a in 0 5 10 20 40 60 80
#do
#        c=`cat dev.txt | grep "$a% " -c`
#        total=0
#        for b in $(eval echo "{1..$c}")
#        do
#                value=`cat dev.txt | grep "$a% " -m$b | tail -n1 | rev | cut -d' ' -f1 | rev`
#                total=`echo $total + $value | bc`
#        done
#        total=`echo $total / $c | bc -l`
#        echo "$a%     $total" >> $FILE2
#done
