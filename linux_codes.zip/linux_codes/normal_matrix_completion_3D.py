#one file code - incomplete VCs - setting bounds

#! ~/anaconda/bin/python
import pandas as pa
import numpy as np
import scipy.spatial.distance as spa
from scipy.sparse.csgraph import dijkstra
import scipy as sp
import random
import matplotlib.pyplot as plt
import math
# from repo.dimredu import MCviaIALMFast  #this gives problem
from dimredu import MCviaIALMFast
# from playground.src import MCviaIALMFast  #this doesnt give any problem

from mpl_toolkits.mplot3d import axes3d, Axes3D 




## defining variables:-------------------
global col_size
global n
global row_size
global row_size
global col_size

n = 0
col_size = 0
row_size = 0



def rand_removal(VC,C,fraction):

  [Rn, Cn] = VC.shape
  rem_num = (Rn*Cn*fraction/100) # total number of entries to be removed
  rem_num = int(rem_num) 

  VCcopy = np.copy(VC)
  # print (rem_num)

  RR = np.random.choice(Rn, rem_num)
  CC = np.random.choice(Cn, rem_num)

  VCr = np.copy(VC)
  for xx in range(rem_num):
    i=RR[xx]
    j=CC[xx]
    VCr[i][j] = 0
    VCcopy[i][j] = -1
  return(VCr,rem_num,VCcopy)



## start of code:------------------------

flag = 0 #0 for random or 1 for ens
fraction = 0 #percentage of elements to be removed

#the below is always 0
# removal = 0    #0 for random removal of elements 1 for removing last set of elements
# lets just do random removal


# var = np.loadtxt('spiral.txt',delimiter='\t')
# var = np.loadtxt('odd_shaped.txt',delimiter='\t')
# var = np.loadtxt('three-void.txt',delimiter='\t')

# var = np.load('T_coor.npy')
var = np.load('hourglass_coor.npy')
D = spa.pdist(var,'euclidean')
sqr=spa.squareform(D)
r=1
adj=+spa.squareform(D<=r)
n=len(var)
row_size = n
sps = sp.sparse.coo_matrix(adj)
A = np.array(dijkstra(sps))

# print (var[:,1] )

# exit() 


# --------------plot 3D------------------------

# fig = plt.figure()
# ax = Axes3D(fig)

# # ax.tick_params(axis='both', which='major', labelsize=12)
# ax.scatter(var[:,0],var[:,1],var[:,2], c=var[:,2])
# # ax.scatter(xs, ys, zs, c=c, marker=m)
# ax.set_xlabel('X')
# ax.set_ylabel('Y')
# ax.set_zlabel('Z')
# # ax.set_ylim((-1000,1000))
# # ax.set_xlim((-1000,1000))
# plt.show()

# exit()

# ---------------------------------




##select random anchors from VC matrix = A
# rand_ens(A)



col_size = 20
if fraction == 0:
	C = np.array(random.sample(range(0,row_size),col_size))
	np.save('random_anchors.npy',C)
else:
	C = np.load('random_anchors.npy')

# if flag == 0:
    # col_size = 20
    # C = np.array(random.sample(range(0,row_size),col_size))
    # np.save('random_anchors.npy',C)
    # C = np.load('three_random_anchors.npy')
    # print (C)
    # np.savetxt('rand_anchors.txt',C.astype(int))
# elif flag == 1: #to select ENS anchors
    
    # col_size = 9
    # C = np.array([4,109,0,11,26,145,213,222,495]) #threevoid
    # C = np.array([11, 22, 26, 222, 320, 457, 458, 489])  # odd shaped
    # col_size = len(C)
    
# else:
    # print ("flag is missing")

# C = np.load('T_anchors_best20_rand1.npy')  ###random anchors
# C = np.array([0,11,44,55,127,159,160,192,794,819,820,845,1447,1479,1480,1512,1584,1595,1628,1639]) ##random anchors chosen for hourglass cube

VC =  A[:,C]
# print (VC[0,:])
# exit()



# print ("Hello there---------")
# print (C)
#random removal 
# VC_remaining = rand_individ(VC,C)
# print (type(VC))
# print (type(C))
# print (type(fraction))

[VC_removed, removed, VCc] = rand_removal(VC,C,fraction)
# print (VC_removed)
# print ("total removed entries: ", removed)
# print ("fraction: ", fraction)

# ---------------------------------cerate double centered matrix---------------------
m,n = VC_removed.shape
S = np.zeros((m,n))

# replace all elements of S by (-1)
for i in range(m):
  for j in range(n):
    S[i,j] = -1

# get doublecentered S from partially observed VC = VCc
VCp = np.copy(VCc)
VCp = np.square(VCp)

# mean of all observed entries in VCp:
total = 0
count = 0
for i in range(m):
  for j in range(n):
    if VCc[i,j] != (-1):
      total = total + VCp[i,j]
      count = count + 1

# thus mean of all observed entries = full_mean = 
full_mean = total/count


for i in range(m):
  for j in range(n):
    if VCc[i,j] != (-1):
      v1 = VCp[i,j]

      loc = np.where( VCc[:,j] != (-1) )
      loc = np.asarray(loc)
      loc = loc[0]
      ll = len(loc)
      v2 = ( sum(VCp[loc,j]) )/ll
      
      loc = np.where( VCc[i,:] != (-1) )
      loc = np.asarray(loc)
      loc = loc[0]
      ll = len(loc)
      v3 = ( sum(VCp[i,loc]) )/ll
      
      v4 = full_mean

      val = v1 - v2 - v3 + v4
      S[i,j] = (-0.5)*val

# print ('-----------done double centering--------------')

# replace all -1 values in S by 0:
for i in range(m):
  for j in range(n):
    if S[i,j] == (-1):
      S[i,j] = 0

# ----------------------------------calling Matrix Completion----------
 
m,n = VC_removed.shape
# print ('m,n = ',m,n)
# create u,v and vecM vectors
# u = np.zeros(1)
# v = np.zeros(1)
# vecM = np.zeros(1)
u = []
v = []
vecM = []
for i in range(m):
  for j in range(n):
    if VCc[i,j] != (-1):
      u.append(i)
      v.append(j)
      vecM.append(S[i,j])
maxRank = col_size
u = np.asarray(u)

# print ('*******************')

v = np.asarray(v)
vecM = np.asarray(vecM)


# exit()

U, E, VT = MCviaIALMFast.MC(m,n,u,v,vecM,maxRank)

# print ('U:',U)
# print (U.shape)

# print ('E:',E)
# print (E.shape)

# print ('VT:',VT)
# print (VT.shape)
VT = VT.transpose()
Psvd = np.dot(U,np.diag(E))
# print (Psvd.shape)
Psvd = np.array(Psvd)


# fig = plt.figure()
# ax = Axes3D(fig)

# ax.tick_params(axis='both', which='major', labelsize=12)
# ax.scatter(Psvd[:,0],Psvd[:,1],Psvd[:,2], c=Psvd[:,2])
# ax.scatter(xs, ys, zs, c=c, marker=m)
# ax.set_xlabel('X')
# ax.set_ylabel('Y')
# ax.set_zlabel('Z')
# ax.set_ylim((-1000,1000))
# ax.set_xlim((-1000,1000))
# plt.show()
# ----------------------------------------

dc = np.zeros( (len(Psvd), 3) )
dc[:,0] = Psvd[:,0]
dc[:,1] = Psvd[:,1]
dc[:,2] = Psvd[:,2]

np.savetxt('nw_0.txt', dc, delimiter = '\t')



# plt.savefig('odd_0.png')
# plt.show()
