#!~/anaconda3/bin/python3.6

###one file code - incomplete VCs - setting bounds

import pandas as pa
import numpy as np
import scipy.spatial.distance as spa
from scipy.sparse.csgraph import dijkstra
import scipy as sp
import random
import matplotlib.pyplot as plt
import math
# from repo.dimredu import MCviaIALMFast  #this gives problem
from dimredu import MCviaIALMFast
# from playground.src import MCviaIALMFast  #this doesnt give any problem





## defining variables:-------------------
global col_size
global n
global row_size
global row_size
global col_size

n = 0
col_size = 0
row_size = 0

print ('--------matric completion code-----------')

def rand_removal(VC,C,fraction):

  [Rn, Cn] = VC.shape
  rem_num = (Rn*Cn*fraction/100) # total number of entries to be removed
  rem_num = int(rem_num) 

  VCcopy = np.copy(VC)
  # print (rem_num)

  RR = np.random.choice(Rn, rem_num)
  CC = np.random.choice(Cn, rem_num)

  VCr = np.copy(VC)
  for xx in range(rem_num):
    i=RR[xx]
    j=CC[xx]
    VCr[i][j] = 0
    VCcopy[i][j] = -1
  return(VCr,rem_num,VCcopy)



## start of code:------------------------

flag = 0 #0 for random or 1 for ens
fraction = 0 #percentage of elements to be removed

#the below is always 0
# removal = 0    #0 for random removal of elements 1 for removing last set of elements
# lets just do random removal


# var = np.loadtxt('spiral.txt',delimiter='\t')
var = np.loadtxt('odd_shaped.txt',delimiter='\t')
# var = np.loadtxt('three-void.txt',delimiter='\t')


D = spa.pdist(var,'euclidean')

#gives Distance matrix in square form
sqr = spa.squareform(D)
#defining radius of connection of a node: r
r = 1
#extracting connectivity matrix = adj as per the connetivity
adj =+ spa.squareform(D<=r)
#stores number of nodes in 'n'
n = len(var)
row_size = n
#convert the adj matrix into sparse form
sps = sp.sparse.coo_matrix(adj)
#create a complete distance matrix
A = np.array(dijkstra(sps))

##select random anchors from VC matrix = A
# rand_ens(A)


col_size = 20
if fraction == 0:
	C = np.array(random.sample(range(0,row_size),col_size))
	np.save('random_anchors.npy',C)
else:
	C = np.load('random_anchors.npy')



VC =  A[:,C]
# print (VC[0,:])
# exit()



# print ("Hello there---------")
# print (C)
#random removal 
# VC_remaining = rand_individ(VC,C)
# print (type(VC))
# print (type(C))
# print (type(fraction))

[VC_removed, removed, VCc] = rand_removal(VC,C,fraction)
# print (VC_removed)
# print ("total removed entries: ", removed)
# print ("fraction: ", fraction)

# ---------------------------------cerate double centered matrix---------------------
m,n = VC_removed.shape
S = np.zeros((m,n))

# replace all elements of S by (-1)
for i in range(m):
  for j in range(n):
    S[i,j] = -1

# get doublecentered S from partially observed VC = VCc
VCp = np.copy(VCc)
VCp = np.square(VCp)

# mean of all observed entries in VCp:
total = 0
count = 0
for i in range(m):
  for j in range(n):
    if VCc[i,j] != (-1):
      total = total + VCp[i,j]
      count = count + 1

# thus mean of all observed entries = full_mean = 
full_mean = total/count


for i in range(m):
  for j in range(n):
    if VCc[i,j] != (-1):
      v1 = VCp[i,j]

      loc = np.where( VCc[:,j] != (-1) )
      loc = np.asarray(loc)
      loc = loc[0]
      ll = len(loc)
      v2 = ( sum(VCp[loc,j]) )/ll
      
      loc = np.where( VCc[i,:] != (-1) )
      loc = np.asarray(loc)
      loc = loc[0]
      ll = len(loc)
      v3 = ( sum(VCp[i,loc]) )/ll
      
      v4 = full_mean

      val = v1 - v2 - v3 + v4
      S[i,j] = (-0.5)*val

# print ('-----------done double centering--------------')

# replace all -1 values in S by 0:
for i in range(m):
  for j in range(n):
    if S[i,j] == (-1):
      S[i,j] = 0

# ----------------------------------calling Matrix Completion----------
 
m,n = VC_removed.shape
# print ('m,n = ',m,n)
# create u,v and vecM vectors
# u = np.zeros(1)
# v = np.zeros(1)
# vecM = np.zeros(1)
u = []
v = []
vecM = []
for i in range(m):
  for j in range(n):
    if VCc[i,j] != (-1):
      u.append(i)
      v.append(j)
      vecM.append(S[i,j])
maxRank = col_size
u = np.asarray(u)

# print ('*******************')

v = np.asarray(v)
vecM = np.asarray(vecM)


# exit()

U, E, VT = MCviaIALMFast.MC(m,n,u,v,vecM,maxRank)

# print ('U:',U)
# print (U.shape)

# print ('E:',E)
# print (E.shape)

# print ('VT:',VT)
# print (VT.shape)
VT = VT.transpose()
Psvd = np.dot(U,np.diag(E))
# print (Psvd.shape)
Psvd = np.array(Psvd)
# fig = plt.figure(1)
# We define a fake subplot that is in fact only the plot.  
# plot = fig.add_subplot(111)

# We change the fontsize of minor ticks label 
# plot.tick_params(axis='both', which='major', labelsize=12)
# plot.tick_params(axis='both', which='minor', labelsize=20)

# plt.scatter(Psvd[:,0],Psvd[:,1])
# plt.xlabel('$S^{(1st)}SVD$')
# plt.ylabel('$S^{(2nd)}SVD$')

dc = np.zeros( (len(Psvd), 2) )
dc[:,0] = Psvd[:,0]
dc[:,1] = Psvd[:,1]

np.savetxt('nw_0.txt', dc, delimiter = '\t')

# plt.savefig('nw_0.png')


# plt.show()
