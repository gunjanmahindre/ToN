# -*- coding: utf-8 -*-
"""
Created on Mon Oct  2 15:30:41 2017

@author: kel, gunjan
"""
import pandas as pa
import scipy.spatial.distance as spa
from scipy.sparse.csgraph import dijkstra
import scipy as sp
import random
import math

import numpy as np
from sklearn.neighbors import BallTree
from scipy.sparse.csgraph import floyd_warshall
import matplotlib.pyplot as plt

plt.close('all')

print('loading --------------------')

import os
path = ("C:/Users/Puzzle Assembly/Desktop/other files/precipitate")
# print (path)


# exit()


# path = 'files'

#  load original TPM for reference

original = np.loadtxt('nw_0.txt')
x = original.min()
x = np.abs(x)
original = np.add(original,x)
# odd = np.loadtxt('odd_0.txt')

nw_5 = np.loadtxt('nw_5.txt')
x = nw_5.min()
x = np.abs(x)
nw_5 = np.add(nw_5,x)

nw_10 = np.loadtxt('nw_10.txt')
x = nw_10.min()
x = np.abs(x)
nw_10 = np.add(nw_10,x)

nw_20 = np.loadtxt('nw_20.txt')
x = nw_20.min()
x = np.abs(x)
nw_20 = np.add(nw_20,x)

nw_40 = np.loadtxt('nw_40.txt')
x = nw_40.min()
x = np.abs(x)
nw_40 = np.add(nw_40,x)

nw_60 = np.loadtxt('nw_60.txt')
x = nw_60.min()
x = np.abs(x)
nw_60 = np.add(nw_60,x)

nw_80 = np.loadtxt('nw_80.txt')
x = nw_80.min()
x = np.abs(x)
nw_80 = np.add(nw_80,x)


nw_90 = np.loadtxt('nw_90.txt')
x = nw_90.min()
x = np.abs(x)
nw_90 = np.add(nw_90,x)

r,c = original.shape


A = original

# 5%
B = nw_5
dista = spa.cdist(A,A,'euclidean')
distb = spa.cdist(B,B,'euclidean')
di = dista-distb
# print (np.sum(np.absolute(di))/np.sum(dista))
x5 = np.sum(np.absolute(di))/np.sum(dista)

# 10%
B = nw_10
dista = spa.cdist(A,A,'euclidean')
distb = spa.cdist(B,B,'euclidean')
di = dista-distb
# print (np.sum(np.absolute(di))/np.sum(dista))
x10 = np.sum(np.absolute(di))/np.sum(dista)

# 20%
B = nw_20
dista = spa.cdist(A,A,'euclidean')
distb = spa.cdist(B,B,'euclidean')
di = dista-distb
# print (np.sum(np.absolute(di))/np.sum(dista))
x20 = np.sum(np.absolute(di))/np.sum(dista)

# 40%
B = nw_40
dista = spa.cdist(A,A,'euclidean')
distb = spa.cdist(B,B,'euclidean')
di = dista-distb
# print (np.sum(np.absolute(di))/np.sum(dista))
x40 = np.sum(np.absolute(di))/np.sum(dista)

# 60%
B = nw_60
dista = spa.cdist(A,A,'euclidean')
distb = spa.cdist(B,B,'euclidean')
di = dista-distb
# print (np.sum(np.absolute(di))/np.sum(dista))
x60 = np.sum(np.absolute(di))/np.sum(dista)

# 80%
B = nw_80
dista = spa.cdist(A,A,'euclidean')
distb = spa.cdist(B,B,'euclidean')
di = dista-distb
# print (np.sum(np.absolute(di))/np.sum(dista))
x80 = np.sum(np.absolute(di))/np.sum(dista)

# 90%
B = nw_90
dista = spa.cdist(A,A,'euclidean')
distb = spa.cdist(B,B,'euclidean')
di = dista-distb
# print (np.sum(np.absolute(di))/np.sum(dista))
x90 = np.sum(np.absolute(di))/np.sum(dista)

# print (np.sum(np.absolute(np.tril(di)))/np.sum(np.tril(dista)))


# make an array of mean errors
line100 = []
line100 = np.insert(line100, 0, x90)
line100 = np.insert(line100, 0, x80)
line100 = np.insert(line100, 0, x60)
line100 = np.insert(line100, 0, x40)
line100 = np.insert(line100, 0, x20)
line100 = np.insert(line100, 0, x10)
line100 = np.insert(line100, 0, x5)
line100 = np.insert(line100, 0, 0)

x = [0, 5, 10, 20, 40, 60, 80, 90]

hs = open("mean.txt","a")
hs.write(str('Iteration_1'))

for i in range(8):
	# hs = open("mean.txt","a")
	hs.write('\n')
	hs.write(format(x[i]))
	hs.write('%')
	hs.write(' ')
	hs.write(format(line100[i]))
hs.write('\n')
hs.write('\n')
hs.close() 


print('mean:',line100)

# x = [0, 5, 10, 20, 40, 60, 80, 90]
# plt.figure(1)

# ------------to plot without error bars---------------------------------------------------------------------------------------

# plt.plot( x,line100, 'bo-', markeredgecolor='black', label='Circular Network with three voids')
# plt.plot( x,line150, 'y^-', markeredgecolor='black', label='Facebook Network - 100 anchors')
# plt.plot( x,line200, 'rs-', markeredgecolor='black', label='Facebook Network - 150 anchors')

# plt.title('Mean error - Facebook network - different anchors')
# plt.xlabel('(%) Missing Coordinates in VC Matrix')
# plt.ylabel('Mean Error (%)')
# plt.legend(loc='upper left') 



# plt.margins(x=0)

# plt.show()

exit()

